import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';

var app = express();
app.use(cors());
var PORT = 80;

app.get('/', function (req, res) {
  res.redirect('/forecastdata');
});


app.get('/forecastdata', function (req, res) {
  const url = "https://api.weatherapi.com/v1/forecast.json?key=3738897fde7047f0a1822737203011&q=20171&days=1";

  const fetchData = async () => {
    try {
      const response = await fetch(url);
      const data = await response.json();
      var forecastArr = [];
      for (var i = 0; i < data.forecast.forecastday[0].hour.length; i++) {
        forecastArr.push({
          time: data.forecast.forecastday[0].hour[i].time,
          temp_f: data.forecast.forecastday[0].hour[i].temp_f
        });
      }
      res.json([{
        current: {
          temp_f: data.current.temp_f
        },
        forecast: forecastArr
      }]);
    } catch (error) {
      console.log("error", error);
    }
  };

  fetchData();
});


app.listen(PORT, function () {
  console.log('Server is running on PORT:', PORT);
});